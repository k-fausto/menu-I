/**
 * Karim Boujana Marcucci.
 */

#include <math.h> 
double f_3(double x);

double f_4(double x) {
    return f_3(x)*f_3(x);
}