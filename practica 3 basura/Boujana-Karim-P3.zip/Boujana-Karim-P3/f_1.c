/**
 * Karim Boujana Marcucci.
 */

#include <math.h> 

double f_1(double x) {
    return exp(x);
}