/**
 * Karim Boujana Marcucci.
 */

#include <math.h> 

double f_2(double x) {
    return fabs(x);
}