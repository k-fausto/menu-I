/**
 * Karim Boujana Marcucci.
 */

#include <math.h> 

double f_3(double x) {
    return 1/(1+25*x*x);
}