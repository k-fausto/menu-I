/**
 * Karim Boujana Marcucci.
 */

#include <math.h>
double f(double x) { return log(x) - (x*x) + (4.0*x) - (4.0); }