/**
 * Karim Boujana Marcucci.
 */

#include <math.h>
double f(double x) { return x*x*x - exp(x) + 3.0; }