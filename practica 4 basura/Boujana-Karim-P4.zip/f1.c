/**
 * Karim Boujana Marcucci.
 */

double f(double x) { return (1.0)/(1.0+x); }