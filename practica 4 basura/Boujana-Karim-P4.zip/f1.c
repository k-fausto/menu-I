/**
 * Karim Boujana Marcucci.
 */

#include <math.h>
double f(double x) { return (1.0)/(1.0+x); }
double f_prim(double x) { return log(fabs(1.0+x)); }