/**
 * Karim Boujana Marcucci.
 */

#include <math.h>
double f(double x) { return (exp(2.0*x)*sin(3.0*x)); }